const express = require("express");
const app = express();
const mongoose = require("mongoose");
const path = require("path");
const Recipe = require("./Models/Recipe");

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static("public"));
app.use(express.static(path.join(__dirname, "public")));

mongoose
  .connect(
    "mongodb+srv://shivanshupandey14:s76rSUqKF3D6PsJ8@mycluster.odbglx5.mongodb.net/foodrec?retryWrites=true&w=majority&appName=MyCluster",
    {}
  )
  .then(() => {
    console.log("Connected to MongoDB Atlas");
  })
  .catch((err) => {
    console.error("Error connecting to MongoDB Atlas:", err.message);
  });

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

app.get("/api/recipe", async (req, res) => {
  try {
    const recipes = await Recipe.find({});
    console.log(recipes);
    res.status(200).json(recipes);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

app.get("/api/recipe/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const recipe = await Recipe.findById(id);
    if (!recipe) {
      res.status(404).json({ messahe: "Recipe Not found" });
    }

    res.status(200).json(recipe);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

app.post("/api/recipe", async (req, res) => {
  try {
    const recipe = await Recipe.create(req.body);

    res.status(200).json(recipe);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

app.put("/api/recipe/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const recipe = await Recipe.findByIdAndUpdate(id, req.body);

    if (!recipe) {
      res.status(404).json({ messahe: "Recipe Not found" });
    }

    const newrecipe = await Recipe.findById(id);

    res.status(200).json(newrecipe);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

app.delete("/api/recipe/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const recipe = await Recipe.findByIdAndDelete(id);
    if (!recipe) {
      res.status(404).json({ messahe: "Recipe Not found" });
    }

    res.status(200).json({ message: "Deleted" });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

app.listen(3000, () => {
  console.log("Listening on localhost:3000");
});
